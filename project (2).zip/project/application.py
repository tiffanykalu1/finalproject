import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, url_for
from flask_session import Session
from tempfile import mkdtemp
from datetime import datetime
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from flask_mail import Message, Mail
from flask_wtf import FlaskForm
from wtforms import StringField, TextField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Length, Email 


# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True


# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

app.secret_key = 'development key'
# Configure mail
 
app.config["MAIL_SERVER"] = "imap.gmail.com"
app.config["MAIL_PORT"] = 465
app.config["MAIL_USE_SSL"] = True
app.config["MAIL_USERNAME"] = "doyouknowyourhaircarebaby@gmail.com"
app.config["MAIL_PASSWORD"] = "MeganTheeStallion2020"

mail = Mail(app)

#Create form on "Contact Us" page
class ContactForm(FlaskForm):
  name = StringField("Name",  validators=[DataRequired("Please enter your name.")])
  email = StringField("Email",  validators=[DataRequired("Please enter your email address."), Email("Please enter your email address.")])
  subject = TextAreaField("Subject",  validators=[DataRequired("Please enter a subject.")])
  message = TextAreaField("Message",  validators=[DataRequired("Please enter a message.")])
  submit = SubmitField("Send")


 
 

 


# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///hairessentials.db")

# Home page
@app.route("/")
@app.route("/home")
def home():
    return render_template("home.html")

# About me page
@app.route("/aboutme")
def aboutme():
    return render_template("aboutme.html")

#First page of the questionnaire. After question is submitted, user will be taken to a page for their answer
@app.route("/questionnaire1", methods=["GET", "POST"])
def questionnaire1():
    if request.method == "GET":
        return render_template("questionnaire1.html")
    else:
        q1 = request.form.get("q1")
        if not q1:
            flash("Answer the questions")
            return redirect("/questionnaire1")
        if q1 == "type3":
            type3 = db.execute("SELECT * FROM type3")
            return render_template("tailored1.html", type3 = type3)
        if q1 == "type4":
            type4 = db.execute("SELECT * FROM type4")
            return render_template("tailored1.html", type4 = type4)
            
@app.route("/tailored1", methods=["GET", "POST"])
def tailored1():
    if request.method == "GET":
        return render_template("tailored1.html")
    else:
        return render_template("questionnaire2.html")

@app.route("/questionnaire2", methods=["GET", "POST"])
def questionnaire2():
    if request.method == "GET":
        return render_template("questionnaire1.html")
    else:
        q2 = request.form.get("q2")
        if not q2:
            flash("Answer the questions")
            return redirect("/questionnaire2")
        if q2 == "low":
            return render_template("tailored21.html")
            
        if q2 == "medium":
            return render_template("tailored22.html")
            
        if q2 == "high":
            return render_template("tailored23.html")
            
@app.route("/tailored21", methods=["GET", "POST"])
def tailored21():
    if request.method == "GET":
        return render_template("tailored21.html")
    else:
        return render_template("questionnaire3.html")
        
@app.route("/tailored22", methods=["GET", "POST"])
def tailored22():
    if request.method == "GET":
        return render_template("tailored22.html")
    else:
        return render_template("questionnaire3.html")
        
@app.route("/tailored23", methods=["GET", "POST"])
def tailored23():
    if request.method == "GET":
        return render_template("tailored23.html")
    else:
        return render_template("questionnaire3.html")
            
@app.route("/questionnaire3", methods=["GET", "POST"])
def questionnaire3():
    if request.method == "GET":
        return render_template("questionnaire3.html")
    else:
        q3 = request.form.get("q3")
        if not q3:
            flash("Answer the question")
            return redirect("/questionnaire3")
        if q3 == "ear":
            return render_template("tailored31.html")
        if q3 == "neck":
            return render_template("tailored32.html")
        if q3 == "shoulder":
            return render_template("tailored33.html")
        
        
@app.route("/tailored31", methods=["GET", "POST"])
def tailored31():
    if request.method == "GET":
        return render_template("tailored31.html")

@app.route("/tailored32", methods=["GET", "POST"])
def tailored32():
    if request.method == "GET":
        return render_template("tailored32.html")

@app.route("/tailored33", methods=["GET", "POST"])
def tailored33():
    if request.method == "GET":
        return render_template("tailored33.html")

@app.route("/tailored33", methods=["GET", "POST"])
def tailored34():
    if request.method == "GET":
        return render_template("tailored34.html")
        

        
@app.route("/info")
def info():
    return render_template("info.html")
    


@app.route("/salons", methods=["GET", "POST"])
def salons():
    if request.method == "GET":
        return render_template("salons.html")
    else:
        if request.form.get("salons") == "name1":
            asc = db.execute("SELECT * FROM salons ORDER BY name ASC")
            return render_template("salons.html", asc = asc)

        if request.form.get("salons") == "name2":
            desc = db.execute("SELECT * FROM salons ORDER BY name DESC")
            return render_template("salons.html", desc = desc)

        if request.form.get("salons") == "distance":
            distance = db.execute("SELECT * FROM salons ORDER BY distance ASC")
            return render_template("salons.html", distance = distance)

        if request.form.get("salons") == "rating1":
            rating1 = db.execute("SELECT * FROM salons ORDER BY rating DESC")
            return render_template("salons.html", rating1 = rating1)

        if request.form.get("salons") == "rating2":
            rating2 = db.execute("SELECT * FROM salons ORDER BY rating ASC")
            return render_template("salons.html", rating2 = rating2)





@app.route("/beautysupply", methods=["GET", "POST"])
def beautysupply():
    if request.method == "GET":
        return render_template("beautysupply.html")
    else:
        if request.form.get("beautysupply") == "name1":
            asc = db.execute("SELECT * FROM beautysupply ORDER BY name ASC")
            return render_template("beautysupply.html", asc = asc)

        if request.form.get("beautysupply") == "name2":
            desc = db.execute("SELECT * FROM beautysupply ORDER BY name DESC")
            return render_template("beautysupply.html", desc = desc)

        if request.form.get("beautysupply") == "distance":
            distance = db.execute("SELECT * FROM beautysupply ORDER BY distance ASC")
            return render_template("beautysupply.html", distance = distance)




@app.route("/newbusiness", methods=["GET", "POST"] )
def newbusiness():
    if request.method == "GET":
        return render_template("newbusiness.html")
    # POST
    else:
        Name = request.form.get("Name")
        Address = request.form.get("Address")
        Distance = request.form.get("Distance")
        Number = request.form.get("Number")
        
        # Validate form submission
        if not request.form.get("Name"):
            flash("Missing name")
            return redirect("/newbusiness")

        if not request.form.get("Address"):
            flash("Missing address")
            return redirect("/newbusiness")

        if not request.form.get("Distance"):
            flash("Missing distance")
            return redirect("/newbusiness")
            
        if not request.form.get("Number"):
            flash("Missing number")
            return redirect("/newbusiness")
            
        duplicates = db.execute("SELECT name FROM salons WHERE Name = :Name", Name = request.form.get("Name"))
        
        if len(duplicates) > 0:
            flash("This business is already in our database, enter a new one")
            return redirect("/newbusiness")
            
        duplicates2 = db.execute("SELECT name FROM beautysupply WHERE Name = :Name", Name = request.form.get("Name"))
        
        if len(duplicates2) > 0:
            flash("This business is already in our database, enter a new one")
            return redirect("/newbusiness")
            
      

        # Add business to database
        if request.form.get("businesstype") == "salon":
            db.execute("INSERT INTO salons (Name, Address, Distance, Number) VALUES(:Name, :Address, :Distance, :Number)", Name = Name, Address = Address, Distance = Distance, Number = Number)
            flash("Submitted!")
            return redirect("/newbusiness")
            
        if request.form.get("businesstype") == "beautysupply":
            db.execute("INSERT INTO beautysupply (Name, Address, Distance) VALUES(:Name, :Address, :Distance)", Name = Name, Address = Address, Distance = Distance)
            flash("Submitted!")
            return redirect("/newbusiness")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    form = ContactForm()
 
    if request.method == 'POST':
        if form.validate_on_submit() == False:
            flash('All fields are required.')
            return render_template("contact.html", form=form)
        else:
            
            msg = Message(form.subject.data, sender="doyouknowyourhaircarebaby@gmail.com", recipients=["doyouknowyourhaircarebaby@gmail.com"])
            msg.body = '''
            From %s <%s> 
            %s
            ''' % (form.name.data, form.email.data, form.message.data)
      
            mail.send(msg)
            return render_template("contact.html", form=form, success=True)
 
    
 
    elif request.method == 'GET':
        return render_template("contact.html", form=form)