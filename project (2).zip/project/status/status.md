# Status Report

#### Your name

Tiffany Kalu

#### Your section leader's name

Ashley Wong

#### Project title

Do You Know Your Hair Care, Baby?

***

Short answers for the below questions suffice. If you want to alter your plan for your project (and obtain approval for the same), be sure to email your section leader directly!

#### What have you done for your project so far?

Made the layout.html, exported the code for application.py, made a logo for the project

#### What have you not done for your project yet?

Create the questions for the questionnaire, made the sql database for the questionnaire, finished the rest of the html pages

#### What problems, if any, have you encountered?

In application.py, anytime I run flask I get a 404 not found message or 500 internal server error. Do all the @app.route(/) have to be defined and finsihed in order for the application to run?
