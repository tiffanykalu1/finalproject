Introduction
This project is a website called "Do You Know Your Hair Care Baby", aimed towards Black women and femmes that attend Harvard who want to
better their hair care experience while we're on campus.
There are multiple sections on this site that the user can dynamically interact with. It is a web application based on Flask framework.

Tools
Front End: HTML, CSS
Backend: Python Flask, SQL, Jinja

Page by Page Tour

layout.html: This is the base html for each page. Includes breadcrumbs for each page so every page is accessible no matter what page you're on.

styles.css: Uses Bootstrap and an imported Material Design Boostrap library. Star is used as divider in the breadcrumb for aesthetic


Home: home.html Extends from layout.html. @app.route("/home")

About Me: aboutme.html Extends from layout.html. @app.route("/aboutme")

Custom Hair Care Regimen: Extends from layout.html and route is @app.route("/questionnaire1", methods=["GET", "POST"]). This page can take methods post and get. Get is used when the page is first loaded, and post when the user has submitted their answer to the question.
There are two answer choices "Type 3" and "Type 4". If no answer is selected, the page will flash "answer the questions." Depending on which answer is chosen, python will execute a SQL query of the answer choice, and that SQL query will be passed into tailored1.html. In tailored1.html, there's Jinja if statements for either type3 or type 4, and those values will be passed
into the table that will appear. @app.route("/tailored.html", methods=["GET","POST"]) accepts the method get when it is first loaded, then get when the user clicks the "next" button. This will lead to @app.route("/questionnaire2", methods=["GET", "POST"]). This page takes the method get when it is first posted.
If no answer is selected, the page will flash "answer the questions." When the user selects their answer to their hair porosity (either low, medium, or high), the page for each respective answer choice will load based on the user's answer with an embedded video. When "next" is clicked, this will lead to @app.route("/questionnaire3", methods=["GET", "POST"]).
This accepts get when first loaded and post when the answer is submitted. Based on the user's answer to their length, the page for each respective answer choice will load based on the user's answer with an embedded video with different hairstyles to use. On this last page, there is a link to the "Additional Resources" page.
The flash feature is implemented using jinja.

Salons Near Me: Extends from layout.html. @app.route("/salons", methods=["GET", "POST"]). This page accepts the methods get and post. Get when the page is first loaded, and post when the user selects how they want to sort the salons.
The list of salons are stored in a SQL database, and depending on the sorting type the user selects, python will execute the SQL query. The query is given a variable name (asc, desc, etc). This variable is then passed through salons.html and with the help of jinja if and for statements,
the list will be sorted in that order and inserted into the table.

Beauty Supply Stores Near Me: beautysupply.html. Extends from layout.html. @app.route("/beautysupply", methods=["GET", "POST"]). This page accepts the methods get and post. Get is used when the page is first loaded, and post is used when the user selects how they want to sort the beauty supply stores.
The list of salons are stored are stored in a SQL database, and depending on the sorting type the user selects, python will execute the SQL query. The query is given a variable name (asc. desc, etc). This variable is then passed through beautysupply.html and with the help of jinja if and for statements, 
the list will be sorted in that order and inserted into the table.

Additional Resources: info.html. Extends from layout.html. @app.route("/info"). 

Submit a New Business Here: newbusiness.html. Extends layout.html. @app.route("/newbusiness", methods=["GET", "POST"]). This page accepts the methods get and post. Get is used when the page is first loaded, and post is used when the user submits the form. If the user does not submit a value for all the fields, the message "missing ____" will be flashed. 
Application.py will check whether that salon or beauty supply is already exists in the database, and if so, the page will flash "This business is already in the database. Submit a new one." When there is a successfull submission, the data will be inserted into the SQL database, and the new businesses will be included in the lists on "Beauty Supply Stores Near Me" and "Salons Near Me"

Contact Us: contact.html. Extends from layout.html. @app.route("/contact", methods=["GET", "POST"]). This page accepts the methods get and post. Get is used when the page is first loaded. Post is used when the user submits the form. The user must input in all fields in order to submit successfully. If not, there will be a flashed message letting them know of the missing information. 
Using the flask form and flask mail extensions and configurations, when the form submits successfully, an email will be sent to the email I made for the project, with the person's name, their email, and the subject of their inquiry, and the message. The subject is sent in the subject line, and the rest is sent in the body. 