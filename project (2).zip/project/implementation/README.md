CS50 Final Project - Do You Know Your Hair Care Baby?

About

This project is a website called "Do You Know Your Hair Care Baby", aimed towards Black women and femmes that attend Harvard who want to 
better their hair care experience while we're on campus.
There are multiple sections on this site that the user can dynamically interact with. It is a web application based on Flask framework.

Pages 

Home: This page is the index page and is the first one you'll see when flask is ran.  

About Me: This page just gives some background about me and my purpose for making the project.

Custom Hair Care Regimen: This is the first page out of the three pages to the questionnaire. Once the user answers this question, they will be
taken to a page tailored specifically to their answer with different hair products. Then there's the "Next" button that will take the user to the next question of the questionnaire.
Once the answer is submitted, the user will be taken the next page tailored to their answer with different videos on how to deal with their hair's porosity. There's another "Next" button to direct the user to the last and final question.
Once the answer is submitted, they will be redirect to the page fit for their answer with videos on different hair styles depending on their hair's length. At the bottom, there's a link to the "Additional Resources" page.

Salons Near Me: This page sorts a preloaded set of salons close to Harvard by alphabetical order, reverse alphabetical order, distance from Harvard, ratings from low to high, and ratings from high to low.
The salon's name, address, distance, phone number, and rating will be listed. 
There is a custom Google map embedded with the location of the salons at the bottom

Beauty Supply Stores Near Me: This page sorts a preloaded set of beauty supply stores close to Harvard by alphabetical order, reverse alphabetic order, and distance from Harvard. 
The salon's name, address, distance, phone number, and rating will be listed. There's also an embedded Google map with the locations of each store.

Additional Resources: This page has additional videos people might want to watch based on their needs.

Submit a New Business Here: This page allows users to submit new salons or beauty supply stores into the database because there aren't many in the area, unfortunately. They must submit
the business' name, address, distance, and phone number. This adds to the database, and will then appear in the beauty supply and salons list when you go back to those respective pages.

Contact Us: This page allows the user to submit any inquiries they may have. The user must input thier name, email, subject of inquiry, and the message. Once everything is submitted correctly, 
there will be a confirmation message at the top of the page, and the question will be sent to the email made for this project, doyouknowyourhaircarebaby@gmail.com. 

How to Use

This project can be ran in the CS50 IDE. Requires Python, Flask, CS50, SQL



$ pip install Flask-WTF
$ curl -OL https://github.com/lepture/flask-wtf/tarball/master
$ pip install flask-mail
$ pip install email-validator
$ flask run

Link to YouTube video: https://youtu.be/gTfnwpjUCQk

Note: The code for this project will be sent via email